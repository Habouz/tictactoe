import json as js
import itertools as it
table=list(it.product('xo-',repeat=9))
rtable=[]
dic={}
for i in table:
    rtable.append("".join(i))
for i in rtable:
    temp={}
    for j in range(9):
        if i[j]=='-':
            temp.update({j:0})
    dic.update({i:temp})
file=open('resources.json','w')
js.dump(dic,file)
file.close()
