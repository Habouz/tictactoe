import json as js
file=open('filtered resources.json','r')
dic=js.loads(file.read())
file.close()
def prent(li):
    print(li[0],end=' ')
    print(li[1],end=' ')
    print(li[2])
    print(li[3],end=' ')
    print(li[4],end=' ')
    print(li[5])
    print(li[6],end=' ')
    print(li[7],end=' ')
    print(li[8])
while True:
    gameloop=True
    s=['-','-','-','-','-','-','-','-','-']
    while gameloop:
        prent(s)
        k=int(input('free input.'))-1
        if (s[k]=="-"):
            s[k]="x"
        else:
            continue
        if (((((s[0]=="x")and((((s[1]=="x")and(s[2]=="x"))or((s[3]=="x")and(s[6]=="x")))or((s[8]=="x")and(s[4]=="x"))))or((s[4]=="x")and(((s[1]=="x")and(s[7]=="x"))or((s[3]=="x")and(s[5]=="x")))))or((s[8]=="x")and((((s[7]=="x")and(s[6]=="x"))or((s[5]=="x")and(s[2]=="x"))))))or(((s[2]=="x")and(s[4]=="x"))and(s[6]=="x"))):
            c="You win!"
            gameloop=False
            break
        if "-" not in s:
            c="draw"
            break
        if s[4]=='-' and ((s[0]=='o' and s[8]=='o')or(s[2]=='o' and s[6]=='o')or(s[1]=='o'and s[7]=='o')or(s[3]=='o'and s[5]=='o')):
            hec.update({''.join(s):4})
            s[4]='o'
        elif s[0]=='-' and ((s[1]=='o' and s[2]=='o')or(s[3]=='o' and s[6]=='o')or(s[4]=='o' and s[8]=='o')):
            hec.update({''.join(s):0})
            s[0]='o'
        elif s[2]=='-' and ((s[1]=='o' and s[0]=='o')or(s[5]=='o' and s[8]=='o')or(s[4]=='o' and s[6]=='o')):
            hec.update({''.join(s):2})
            s[2]='o'
        elif s[6]=='-' and ((s[7]=='o' and s[8]=='o')or(s[3]=='o' and s[0]=='o')or(s[4]=='o' and s[2]=='o')):
            hec.update({''.join(s):6})
            s[6]='o'
        elif s[8]=='-' and ((s[6]=='o' and s[7]=='o')or(s[5]=='o' and s[2]=='o')or(s[4]=='o' and s[0]=='o')):
            hec.update({''.join(s):8})
            s[8]='o'
        elif s[1]=='-' and ((s[0]=='o' and s[2]=='o')or(s[4]=='o' and s[7]=='o')):
            hec.update({''.join(s):1})
            s[1]='o'
        elif s[3]=='-' and ((s[0]=='o' and s[6]=='o')or(s[4]=='o' and s[5]=='o')):
            hec.update({''.join(s):3})
            s[3]='o'
        elif s[5]=='-' and ((s[8]=='o' and s[2]=='o')or(s[4]=='o' and s[3]=='o')):
            hec.update({''.join(s):5})
            s[5]='o'
        elif s[7]=='-' and ((s[8]=='o' and s[6]=='o')or(s[4]=='o' and s[1]=='o')):
            hec.update({''.join(s):7})
            s[7]='o'
        elif s[4]=='-' and ((s[0]=='x' and s[8]=='x')or(s[2]=='x' and s[6]=='x')or(s[1]=='x'and s[7]=='x')or(s[3]=='x'and s[5]=='x')):
            hec.update({''.join(s):4})
            s[4]='o'
        elif s[0]=='-' and ((s[1]=='x' and s[2]=='x')or(s[3]=='x' and s[6]=='x')or(s[4]=='x' and s[8]=='x')):
            hec.update({''.join(s):0})
            s[0]='o'
        elif s[2]=='-' and ((s[1]=='x' and s[0]=='x')or(s[5]=='x' and s[8]=='x')or(s[4]=='x' and s[6]=='x')):
            hec.update({''.join(s):2})
            s[2]='o'
        elif s[6]=='-' and ((s[7]=='x' and s[8]=='x')or(s[3]=='x' and s[0]=='x')or(s[4]=='x' and s[2]=='x')):
            hec.update({''.join(s):6})
            s[6]='o'
        elif s[8]=='-' and ((s[7]=='x' and s[6]=='x')or(s[5]=='x' and s[2]=='x')or(s[4]=='x' and s[0]=='x')):
            hec.update({''.join(s):8})
            s[8]='o'
        elif s[1]=='-' and ((s[0]=='x' and s[2]=='x')or(s[4]=='x' and s[7]=='x')):
            hec.update({''.join(s):1})
            s[1]='o'
        elif s[3]=='-' and ((s[0]=='x' and s[6]=='x')or(s[4]=='x' and s[5]=='x')):
            hec.update({''.join(s):3})
            s[3]='o'
        elif s[5]=='-' and ((s[2]=='x' and s[8]=='x')or(s[4]=='x' and s[3]=='x')):
            hec.update({''.join(s):5})
            s[5]='o'
        elif s[7]=='-' and ((s[8]=='x' and s[6]=='x')or(s[4]=='x' and s[1]=='x')):
            hec.update({''.join(s):7})
            s[7]='o'
        else:
            a=''.join(s)
            s[dic[a]]='o'
        if (((((s[0]=="o")and((((s[1]=="o")and(s[2]=="o"))or((s[3]=="o")and(s[6]=="o")))or((s[8]=="o")and(s[4]=="o"))))or((s[4]=="o")and(((s[1]=="o")and(s[7]=="o"))or((s[3]=="o")and(s[5]=="o")))))or((s[8]=="o")and((((s[7]=="o")and(s[6]=="o"))or((s[5]=="o")and(s[2]=="o"))))))or(((s[2]=="o")and(s[4]=="o"))and(s[6]=="o"))):
            c="You Lost."
            gameloop=False
            break
    print(c)
    prent(s)
    k=input("press enter to continue...")
    if k=='n':
        break
