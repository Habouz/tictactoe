import json as js
file=open('resources.json','r')
dic=js.loads(file.read())
file.close()
hec={}
k=0
for i in dic:
    l=0
    for j in dic[i]:
       if dic[i][j]>=l:
           l=dic[i][j]
           k=int(j)
    hec.update({i:k}) 
file=open('filtered resources.json','w')
js.dump(hec,file)
file.close()
print('success!')
