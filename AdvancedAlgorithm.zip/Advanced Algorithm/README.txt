Open  Initial Database Generator.py to reset the program's database
Open Deep Algorithm.py to train the program.
Open Heatmap filter.py to filter the data obtained by training and choose the best options.
Open Game.py to play with the trained program.
